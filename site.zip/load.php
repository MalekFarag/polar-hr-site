<?php
define('ABSPATH', __DIR__);

// EMAIL CONFIG
require_once ABSPATH.'/scripts/mail.php';

// TEMPLATE ENGINE
require_once ABSPATH.'/templates/base/ti.php';